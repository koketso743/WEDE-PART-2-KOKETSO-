document.addEventListener("DOMContentLoaded", function () {
  const links = document.querySelectorAll(".nav-list a");
  const current = window.location.pathname.split("/").pop() || "index.html";

  links.forEach(function (link) {
    const href = link.getAttribute("href");
    if (href === current) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });

  const smoothLinks = document.querySelectorAll('a[href^="#"]');
  smoothLinks.forEach(function (link) {
    link.addEventListener("click", function (event) {
      const targetId = this.getAttribute("href");
      if (targetId === "#") {
        event.preventDefault();
        return;
      }
      const target = document.querySelector(targetId);
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  const dishCards = document.querySelectorAll(".dish-card");
  dishCards.forEach(function (card) {
    card.addEventListener("mouseenter", function () {
      card.style.transform = "translateY(-4px)";
      card.style.transition = "transform 0.2s ease";
      card.style.boxShadow = "0 6px 18px rgba(0,0,0,0.12)";
    });
    card.addEventListener("mouseleave", function () {
      card.style.transform = "translateY(0)";
      card.style.boxShadow = "0 2px 10px rgba(0,0,0,0.06)";
    });
  });

  const images = document.querySelectorAll(".page-image, .hero-image, .team-image");
  images.forEach(function (img) {
    img.addEventListener("click", function () {
      if (img.style.transform === "scale(1.02)") {
        img.style.transform = "scale(1)";
        img.style.transition = "transform 0.3s ease";
      } else {
        img.style.transform = "scale(1.02)";
        img.style.transition = "transform 0.3s ease";
      }
    });
  });

  const formButtons = document.querySelectorAll(".btn-reset");
  formButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      const form = btn.closest("form");
      if (form) {
        form.querySelectorAll(".error-msg").forEach(function (err) {
          err.remove();
        });
        form.querySelectorAll("input, textarea, select").forEach(function (field) {
          if (field.type !== "submit" && field.type !== "reset" && field.type !== "radio") {
            field.style.borderColor = "#d8cfc2";
            field.style.backgroundColor = "#ffffff";
          }
        });
      }
    });
  });

  const phoneLinks = document.querySelectorAll(".location-card p");
  phoneLinks.forEach(function (p) {
    p.innerHTML = p.innerHTML.replace(
      /(0\d{2}\s?\d{3}\s?\d{4})/g,
      '<a href="tel:$1">$1</a>'
    );
  });
});