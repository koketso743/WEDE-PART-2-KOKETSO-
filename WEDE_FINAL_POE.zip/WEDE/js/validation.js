document.addEventListener("DOMContentLoaded", function () {
  const contactForm = document.querySelector(".contact-form");
  const enquiryForm = document.querySelector(".enquiry-form");

  function showError(input, message) {
    input.style.borderColor = "#c0392b";
    input.style.backgroundColor = "#fdecea";
    let error = input.parentElement.querySelector(".error-msg");
    if (!error) {
      error = document.createElement("span");
      error.className = "error-msg";
      error.style.color = "#c0392b";
      error.style.fontSize = "0.85rem";
      error.style.display = "block";
      error.style.marginTop = "4px";
      input.parentElement.appendChild(error);
    }
    error.textContent = message;
  }

  function clearError(input) {
    input.style.borderColor = "#d8cfc2";
    input.style.backgroundColor = "#ffffff";
    const error = input.parentElement.querySelector(".error-msg");
    if (error) {
      error.remove();
    }
  }

  function validateEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function validatePhone(value) {
    return /^[0-9+\s-]{10,15}$/.test(value);
  }

  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      let valid = true;

      const name = contactForm.querySelector('input[name="contactname"]');
      const email = contactForm.querySelector('input[name="contactemail"]');
      const subject = contactForm.querySelector('input[name="subject"]');
      const message = contactForm.querySelector('textarea[name="contactmsg"]');

      [name, email, subject, message].forEach(clearError);

      if (name.value.trim().length < 2) {
        showError(name, "Please enter your name.");
        valid = false;
      }
      if (!validateEmail(email.value.trim())) {
        showError(email, "Please enter a valid email address.");
        valid = false;
      }
      if (subject.value.trim().length < 3) {
        showError(subject, "Please enter a subject.");
        valid = false;
      }
      if (message.value.trim().length < 10) {
        showError(message, "Message must be at least 10 characters.");
        valid = false;
      }

      if (valid) {
        const feedback = document.createElement("p");
        feedback.textContent = "Thank you, " + name.value.trim() + "! Your message has been sent.";
        feedback.style.color = "#2e7d32";
        feedback.style.fontWeight = "bold";
        feedback.style.marginTop = "12px";
        contactForm.appendChild(feedback);
        contactForm.reset();
        setTimeout(function () {
          feedback.remove();
        }, 5000);
      }
    });
  }

  if (enquiryForm) {
    enquiryForm.addEventListener("submit", function (event) {
      event.preventDefault();
      let valid = true;

      const fullname = enquiryForm.querySelector('input[name="fullname"]');
      const email = enquiryForm.querySelector('input[name="email"]');
      const phone = enquiryForm.querySelector('input[name="phone"]');
      const type = enquiryForm.querySelector('input[name="enquirytype"]:checked');
      const message = enquiryForm.querySelector('textarea[name="message"]');

      [fullname, email, phone, message].forEach(clearError);

      if (fullname.value.trim().length < 2) {
        showError(fullname, "Please enter your full name.");
        valid = false;
      }
      if (!validateEmail(email.value.trim())) {
        showError(email, "Please enter a valid email address.");
        valid = false;
      }
      if (phone.value.trim() !== "" && !validatePhone(phone.value.trim())) {
        showError(phone, "Please enter a valid phone number.");
        valid = false;
      }
      if (!type) {
        const legend = enquiryForm.querySelector('fieldset legend');
        if (legend) {
          legend.style.color = "#c0392b";
          setTimeout(function () {
            legend.style.color = "#8b2e1a";
          }, 3000);
        }
        valid = false;
      }
      if (message.value.trim().length < 10) {
        showError(message, "Please tell us more (at least 10 characters).");
        valid = false;
      }

      if (valid) {
        const selected = type.value;
        const feedback = document.createElement("p");
        feedback.textContent = "Enquiry sent! We will respond about your " + selected + " request soon.";
        feedback.style.color = "#2e7d32";
        feedback.style.fontWeight = "bold";
        feedback.style.marginTop = "12px";
        enquiryForm.appendChild(feedback);
        enquiryForm.reset();
        setTimeout(function () {
          feedback.remove();
        }, 5000);
      }
    });
  }
});